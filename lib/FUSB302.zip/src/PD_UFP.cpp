
/**
 * PD_UFP.h
 *
 *      Author: Ryan Ma
 *      Edited: Kai Liebich
 *
 * Minimalist USB PD Ardunio Library for PD Micro board
 * Only support UFP(device) sink only functionality
 * Requires FUSB302_UFP.h, PD_UFP_Protocol.h and Standard Arduino Library
 *
 * Support PD3.0 PPS
 * 
 */
 
#include <stdint.h>
#include <string.h>

#include "PD_UFP.h"

#define t_PD_POLLING            100
#define t_TypeCSinkWaitCap      350
#define t_RequestToPSReady      580     // combine t_SenderResponse and t_PSTransition
#define t_PPSRequest            5000    // must less than 10000 (10s)

#define PIN_FUSB302_INT         12

enum {
    STATUS_LOG_MSG_TX,
    STATUS_LOG_MSG_RX,
    STATUS_LOG_DEV,
    STATUS_LOG_CC,
    STATUS_LOG_SRC_CAP,
    STATUS_LOG_POWER_READY,
    STATUS_LOG_POWER_PPS_STARTUP,
    STATUS_LOG_POWER_REJECT,
    STATUS_LOG_LOAD_SW_ON,
    STATUS_LOG_LOAD_SW_OFF,
};


///////////////////////////////////////////////////////////////////////////////////////////////////
// PD_UFP_c
///////////////////////////////////////////////////////////////////////////////////////////////////
PD_UFP_c::PD_UFP_c():
    ready_voltage(0),
    ready_current(0),
    PPS_voltage_next(0),
    PPS_current_next(0),
    status_initialized(0),
    status_src_cap_received(0),
    status_power(STATUS_POWER_NA),
    time_polling(0),
    time_wait_src_cap(0),
    time_wait_ps_rdy(0),
    time_PPS_request(0),
    get_src_cap_retry_count(0),
    wait_src_cap(0),
    wait_ps_rdy(0),
    send_request(0),
    bridge_mode_enabled(false),
    bridge_log_index(0)
{
    memset(&FUSB302, 0, sizeof(FUSB302_dev_t));
    memset(&protocol, 0, sizeof(PD_protocol_t));
    // 初始化监听数据
    memset(&pd_monitor, 0, sizeof(pd_monitor_t));
}

bool PD_UFP_c::enable_vbus_sense(bool enable)
{
    FUSB302_set_vbus_sense(&FUSB302, enable);
    return true;
}

void PD_UFP_c::init(uint8_t int_pin, enum PD_power_option_t power_option)
{
    init_PPS(int_pin, 0, 0, power_option);
}

void PD_UFP_c::init_PPS(uint8_t int_pin, uint16_t PPS_voltage, uint8_t PPS_current, enum PD_power_option_t power_option)
{
    this->int_pin = int_pin;
    // Initialize FUSB302
    pinMode(int_pin, INPUT_PULLUP); // Set FUSB302 int pin input ant pull up
    FUSB302.i2c_address = 0x22;
    FUSB302.i2c_read = FUSB302_i2c_read;
    FUSB302.i2c_write = FUSB302_i2c_write;
    FUSB302.delay_ms = FUSB302_delay_ms;
    if (FUSB302_init(&FUSB302) == FUSB302_SUCCESS && FUSB302_get_ID(&FUSB302, 0, 0) == FUSB302_SUCCESS) {
        status_initialized = 1;
    }

    // Two stage startup for PPS Voltge < 5V
    if (PPS_voltage && PPS_voltage < PPS_V(5.0)) {
        PPS_voltage_next = PPS_voltage;
        PPS_current_next = PPS_current;
        PPS_voltage = PPS_V(5.0);
    }

    // Initialize PD protocol engine
    PD_protocol_init(&protocol);
    PD_protocol_set_power_option(&protocol, power_option);
    PD_protocol_set_PPS(&protocol, PPS_voltage, PPS_current, false);

    status_log_event(STATUS_LOG_DEV);
}

void PD_UFP_c::run(void)
{
    if (timer() || digitalRead(int_pin) == 0) {
        FUSB302_event_t FUSB302_events = 0;
        for (uint8_t i = 0; i < 3 && FUSB302_alert(&FUSB302, &FUSB302_events) != FUSB302_SUCCESS; i++) {}
        if (FUSB302_events) {
            handle_FUSB302_event(FUSB302_events);
        }
    }
}

//CC线状态获取函数
uint8_t PD_UFP_c::get_cc_pin() {
    uint8_t cc1, cc2;
    FUSB302_get_cc(&FUSB302, &cc1, &cc2);
    
    if (cc1 > 0 && cc2 == 0) {    // CC1有效且CC2无效
        return 1;
    } 
    else if (cc2 > 0 && cc1 == 0) { // CC2有效且CC1无效
        return 2;
    } 
    else {                         // 其他情况（都无效/都有效）
        return 0;
    }
}


bool PD_UFP_c::set_PPS(uint16_t PPS_voltage, uint8_t PPS_current)
{
    if (status_power == STATUS_POWER_PPS && PD_protocol_set_PPS(&protocol, PPS_voltage, PPS_current, true)) {
        send_request = 1;
        return true;
    }
    return false;
}

void PD_UFP_c::set_power_option(enum PD_power_option_t power_option)
{
    if (PD_protocol_set_power_option(&protocol, power_option)) {
        send_request = 1;
    }
}

void PD_UFP_c::clock_prescale_set(uint8_t prescaler)
{
    if (prescaler) {
        clock_prescaler = prescaler;
    }
}

FUSB302_ret_t PD_UFP_c::FUSB302_i2c_read(uint8_t dev_addr, uint8_t reg_addr, uint8_t *data, uint8_t count)
{
    Wire.beginTransmission(dev_addr);
    Wire.write(reg_addr);
    Wire.endTransmission();
    Wire.requestFrom(dev_addr, count);
    while (Wire.available() && count > 0) {
        *data++ = Wire.read();
        count--;
    }
    return count == 0 ? FUSB302_SUCCESS : FUSB302_ERR_READ_DEVICE;
}

FUSB302_ret_t PD_UFP_c::FUSB302_i2c_write(uint8_t dev_addr, uint8_t reg_addr, uint8_t *data, uint8_t count)
{
    Wire.beginTransmission(dev_addr);
    Wire.write(reg_addr);
    while (count > 0) {
        Wire.write(*data++);
        count--;
    }
    Wire.endTransmission();
    return FUSB302_SUCCESS;
}

FUSB302_ret_t PD_UFP_c::FUSB302_delay_ms(uint32_t t)
{
    delay(t / clock_prescaler);
    return FUSB302_SUCCESS;
}

void PD_UFP_c::handle_protocol_event(PD_protocol_event_t events)
{    
    if (events & PD_PROTOCOL_EVENT_SRC_CAP) {
        wait_src_cap = 0;
        get_src_cap_retry_count = 0;
        wait_ps_rdy = 1;
        time_wait_ps_rdy = clock_ms();
        status_log_event(STATUS_LOG_SRC_CAP);
    }
    if (events & PD_PROTOCOL_EVENT_REJECT) {
        if (wait_ps_rdy) {
            wait_ps_rdy = 0;
            status_log_event(STATUS_LOG_POWER_REJECT);
        }
    }    
    if (events & PD_PROTOCOL_EVENT_PS_RDY) {
        PD_power_info_t p;
        uint8_t i, selected_power = PD_protocol_get_selected_power(&protocol);
        PD_protocol_get_power_info(&protocol, selected_power, &p);
        wait_ps_rdy = 0;
        if (p.type == PD_PDO_TYPE_AUGMENTED_PDO) {
            // PPS mode
            FUSB302_set_vbus_sense(&FUSB302, 0);
            if (PPS_voltage_next) {
                // Two stage startup for PPS voltage < 5V
                PD_protocol_set_PPS(&protocol, PPS_voltage_next, PPS_current_next, false);
                PPS_voltage_next = 0;
                send_request = 1;
                status_log_event(STATUS_LOG_POWER_PPS_STARTUP);
            } else {
                time_PPS_request = clock_ms();
                status_power_ready(STATUS_POWER_PPS, 
                    PD_protocol_get_PPS_voltage(&protocol), PD_protocol_get_PPS_current(&protocol));
                status_log_event(STATUS_LOG_POWER_READY);
            }
        } else {
            FUSB302_set_vbus_sense(&FUSB302, 1);
            status_power_ready(STATUS_POWER_TYP, p.max_v, p.max_i);
            status_log_event(STATUS_LOG_POWER_READY);
        }
    }
}

void PD_UFP_c::handle_FUSB302_event(FUSB302_event_t events)
{
    if (events & FUSB302_EVENT_DETACHED) {
        PD_protocol_reset(&protocol);
        
        // Bridge模式下的特殊处理
        if (bridge_mode_enabled) {
            pd_monitor.cc_status = false;
            pd_monitor.cc_pin = 0;
        }
        return;
    }
    if (events & FUSB302_EVENT_ATTACHED) {
        uint8_t cc1 = 0, cc2 = 0, cc = 0;
        FUSB302_get_cc(&FUSB302, &cc1, &cc2);
        PD_protocol_reset(&protocol);
        if (cc1 && cc2 == 0) {
            cc = cc1;
        } else if (cc2 && cc1 == 0) {
            cc = cc2;
        }
        /* TODO: handle no cc detected error */
        if (cc > 1) {
            wait_src_cap = 1;
        } else {
            set_default_power();
        }
        
        // Bridge模式下的CC状态更新
        if (bridge_mode_enabled) {
            pd_monitor.cc_status = true;
            pd_monitor.cc_pin = cc;
        }
        
        status_log_event(STATUS_LOG_CC);
    }
    if (events & FUSB302_EVENT_RX_SOP) {
        PD_protocol_event_t protocol_event = 0;
        uint16_t header;
        uint32_t obj[7];
        FUSB302_get_message(&FUSB302, &header, obj);
        PD_protocol_handle_msg(&protocol, header, obj, &protocol_event);
        
        // Bridge模式下的数据包计数
        if (bridge_mode_enabled) {
            pd_monitor.packet_count++;
        }
        
        status_log_event(STATUS_LOG_MSG_RX, obj);
        if (protocol_event) {
            handle_protocol_event(protocol_event);
        }
    }
    if (events & FUSB302_EVENT_GOOD_CRC_SENT) {
        uint16_t header;
        uint32_t obj[7];
        delay_ms(2);  /* Delay respond in case there are retry messages */
        if (PD_protocol_respond(&protocol, &header, obj)) {
            status_log_event(STATUS_LOG_MSG_TX, obj);
            FUSB302_tx_sop(&FUSB302, header, obj);
        }
        
        // Bridge模式下的Good CRC计数
        if (bridge_mode_enabled) {
            pd_monitor.good_crc_count++;
        }
    }
}

bool PD_UFP_c::timer(void)
{
    uint16_t t = clock_ms();
    if (wait_src_cap && t - time_wait_src_cap > t_TypeCSinkWaitCap) {
        time_wait_src_cap = t;
        if (get_src_cap_retry_count < 3) {
            uint16_t header;
            get_src_cap_retry_count += 1;
            /* Try to request soruce capabilities message (will not cause power cycle VBUS) */
            PD_protocol_create_get_src_cap(&protocol, &header);
            status_log_event(STATUS_LOG_MSG_TX);
            FUSB302_tx_sop(&FUSB302, header, 0);
        } else {
            get_src_cap_retry_count = 0;
            /* Hard reset will cause the source power cycle VBUS. */
            FUSB302_tx_hard_reset(&FUSB302);
            PD_protocol_reset(&protocol);
        }
    }
    if (wait_ps_rdy) {
        if (t - time_wait_ps_rdy > t_RequestToPSReady) {
            wait_ps_rdy = 0;
            set_default_power();
        }
    } else if (send_request || (status_power == STATUS_POWER_PPS && t - time_PPS_request > t_PPSRequest)) {
        wait_ps_rdy = 1;
        send_request = 0;
        time_PPS_request = t;
        uint16_t header;
        uint32_t obj[7];
        /* Send request if option updated or regularly in PPS mode to keep power alive */
        PD_protocol_create_request(&protocol, &header, obj);
        status_log_event(STATUS_LOG_MSG_TX, obj);
        time_wait_ps_rdy = clock_ms();
        FUSB302_tx_sop(&FUSB302, header, obj);
    }
    if (t - time_polling > t_PD_POLLING) {
        time_polling = t;
        return true;
    }
    return false;
}

void PD_UFP_c::set_default_power(void)
{
    status_power_ready(STATUS_POWER_TYP, PD_V(5), PD_A(1));
    status_log_event(STATUS_LOG_POWER_READY);
}

void PD_UFP_c::status_power_ready(status_power_t status, uint16_t voltage, uint16_t current)
{
    ready_voltage = voltage;
    ready_current = current;
    status_power = status;
    // 更新监听数据
    pd_monitor.last_voltage = voltage;
    pd_monitor.last_current = current;
    pd_monitor.power_status = status;
    pd_monitor.last_timestamp = clock_ms();
}

uint8_t PD_UFP_c::clock_prescaler = 1;

void PD_UFP_c::delay_ms(uint16_t ms)
{
    delay(ms / clock_prescaler);
}

uint16_t PD_UFP_c::clock_ms(void)
{
    return (uint16_t)millis() * clock_prescaler;
}

    void PD_UFP_c::update_monitor_info(void)
{
    // 更新时间戳
    pd_monitor.last_timestamp = clock_ms();
    
    if (bridge_mode_enabled) {
        // Bridge模式：只更新监听相关信息，不访问协议状态
        // CC线状态在事件处理中已经更新
        // 电压电流信息在接收到Source Capabilities时更新
        
        // 在Bridge模式下，包计数由事件处理单独更新，避免重复计数
        // 这里可以添加其他Bridge模式特定的更新逻辑
        
        // Bridge模式：保持PD相关字段不变（已在run_Bridge中正确设置）
        // 不覆盖power_status，避免与PDO解析结果冲突
        if (pd_monitor.src_cap_count == 0 && pd_monitor.cc_status) {
            // 如果CC已连接但还没有PDO信息，设置为未知状态
            if (pd_monitor.power_status != STATUS_POWER_PPS && pd_monitor.power_status != STATUS_POWER_TYP) {
                Serial.printf("[UPDATE] 设置power_status为STATUS_POWER_NA (当前: %d)\n", pd_monitor.power_status);
                pd_monitor.power_status = STATUS_POWER_NA;
            }
        }
    } else {
        // 非Bridge模式：正常更新所有信息
        Serial.printf("[UPDATE] 非Bridge模式调用get_ps_status(): %d\n", get_ps_status());
        pd_monitor.last_voltage = get_voltage();
        pd_monitor.last_current = get_current();
        pd_monitor.power_status = get_ps_status();
        pd_monitor.cc_pin = get_cc_pin();
        pd_monitor.cc_status = (pd_monitor.cc_pin != 0);
        pd_monitor.src_cap_count = get_src_cap_count();
        pd_monitor.selected_position = get_selected_position();
    }
    
    // 调试输出：显示update_monitor_info的结果
    Serial.printf("[UPDATE] 完成: V=%umV, I=%umA, power_status=%d, CC=%d\n",
                  pd_monitor.last_voltage, pd_monitor.last_current, pd_monitor.power_status, pd_monitor.cc_status);
}

void PD_UFP_c::reset_monitor_info(void)
{
    memset(&pd_monitor, 0, sizeof(pd_monitor_t));
    pd_monitor.last_timestamp = clock_ms();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Bridge功能方法实现
///////////////////////////////////////////////////////////////////////////////////////////////////

void PD_UFP_c::init_Bridge(uint8_t int_pin)
{
    this->int_pin = int_pin;
    bridge_mode_enabled = true;
    bridge_log_level = PD_BRIDGE_LOG_LEVEL_DETAILED; // 默认使用详细模式
    
    // Initialize FUSB302 for bridge mode
    pinMode(int_pin, INPUT_PULLUP); // Set FUSB302 int pin input and pull up
    FUSB302.i2c_address = 0x22;
    FUSB302.i2c_read = FUSB302_i2c_read;
    FUSB302.i2c_write = FUSB302_i2c_write;
    FUSB302.delay_ms = FUSB302_delay_ms;
    
    if (FUSB302_init(&FUSB302) == FUSB302_SUCCESS && FUSB302_get_ID(&FUSB302, 0, 0) == FUSB302_SUCCESS) {
        status_initialized = 1;
    }
    
    // Bridge模式：不初始化PD协议引擎，避免任何协议处理
    // PD_protocol_init(&protocol);  // 注释掉协议初始化
    
    // Clear bridge log buffer
    memset(bridge_log_buffer, 0, sizeof(bridge_log_buffer));
    bridge_log_index = 0;
    
    // 初始化监听数据
    memset(&pd_monitor, 0, sizeof(pd_monitor_t));
    pd_monitor.last_timestamp = clock_ms();
    
    // 设置默认的监听状态
    pd_monitor.power_status = STATUS_POWER_NA;  // 未知电源状态
    pd_monitor.selected_position = 1;  // 默认选择第一个电源（位置1）
}

void PD_UFP_c::run_Bridge(void)
{
    if (!bridge_mode_enabled) return;
    
    // 移除timer()调用，避免无限循环重启握手
    // 只在有中断或定时轮询时才处理
    if (digitalRead(int_pin) == 0) {
        FUSB302_event_t FUSB302_events = 0;
        for (uint8_t i = 0; i < 3 && FUSB302_alert(&FUSB302, &FUSB302_events) != FUSB302_SUCCESS; i++) {}
        
        if (FUSB302_events) {
            // 纯监听模式：只记录事件，不进行PD握手
            
            if (FUSB302_events & FUSB302_EVENT_DETACHED) {
                // 设备断开连接
                pd_monitor.cc_status = false;
                pd_monitor.cc_pin = 0;
                pd_monitor.packet_count = 0;
                pd_monitor.good_crc_count = 0;
                pd_monitor.reject_count = 0;
                // 不调用PD_protocol_reset，避免重置协议状态
            }
            
            if (FUSB302_events & FUSB302_EVENT_ATTACHED) {
                // 设备连接，只更新监听状态，不触发PD握手
                uint8_t cc1 = 0, cc2 = 0, cc = 0;
                FUSB302_get_cc(&FUSB302, &cc1, &cc2);
                
                if (cc1 && cc2 == 0) {
                    cc = cc1;
                } else if (cc2 && cc1 == 0) {
                    cc = cc2;
                }
                
                pd_monitor.cc_status = true;
                pd_monitor.cc_pin = cc;
                
                // 不调用PD_protocol_reset，保持协议状态不变
                // 不设置wait_src_cap，避免触发PD请求
            }
            
            if (FUSB302_EVENT_RX_SOP & FUSB302_events) {
                // 接收到PD数据包，只统计不处理协议
                uint16_t header;
                uint32_t obj[7];
                FUSB302_get_message(&FUSB302, &header, obj);
                
                pd_monitor.packet_count++;
                
                // 解析PDO信息，获取电压电流信息
                uint16_t msg_header = header;
                uint8_t num_obj = (msg_header >> 12) & 0x07;
                uint8_t msg_type = (msg_header >> 0) & 0x1F; // 修正：使用5位而不是4位
                
                // 调试信息：打印接收到的消息信息
                Serial.printf("[DEBUG] RX: header=0x%04X, num_obj=%d, msg_type=%d\n", 
                              header, num_obj, msg_type);
                for (uint8_t i = 0; i < num_obj && i < 3; i++) {
                    Serial.printf("[DEBUG]   obj[%d]=0x%08lX\n", i, obj[i]);
                }
                
                // 如果是Source Capabilities消息，解析PDO信息
                // 修正：Source Capabilities在data_msg_list中索引为1，所以类型为0x01
                if (num_obj > 0 && msg_type == 0x01) {
                    Serial.println("[DEBUG] Source Capabilities received!");
                    // Source Capabilities消息，解析所有PDO
                    pd_monitor.src_cap_count = num_obj;
                    // 在监听模式下，我们假设选择第一个电源（位置1）
                    pd_monitor.selected_position = 1;
                    
                    // 解析第一个PDO作为默认电源信息
                    if (num_obj > 0) {
                        uint32_t first_pdo = obj[0];
                        uint8_t pdo_type = (first_pdo >> 30) & 0x03;
                        
                        Serial.printf("[DEBUG] PDO0=0x%08lX, type=%d (当前power_status=%d)\n", 
                                      first_pdo, pdo_type, pd_monitor.power_status);
                        
                        switch (pdo_type) {
                            case 0: // Fixed Supply
                                {
                                    uint16_t voltage_raw = ((first_pdo >> 10) & 0x3FF);
                                    uint16_t current_raw = ((first_pdo >> 0) & 0x3FF);
                                    pd_monitor.last_voltage = voltage_raw * 50; // 50mV单位转换为mV
                                    pd_monitor.last_current = current_raw * 10;  // 10mA单位转换为mA
                                    Serial.printf("[DEBUG] 设置为Fixed Supply: V=%umV, I=%umA\n", 
                                                  pd_monitor.last_voltage, pd_monitor.last_current);
                                    pd_monitor.power_status = STATUS_POWER_TYP;
                                    Serial.printf("[DEBUG] Fixed Supply: power_status设置为%d\n", pd_monitor.power_status);
                                    Serial.printf("[DEBUG] Fixed Supply: V=%dmV (%umV raw), I=%dmA (%u raw)\n",
                                                  pd_monitor.last_voltage, voltage_raw, pd_monitor.last_current, current_raw);
                                }
                                break;
                                
                            case 1: // Battery
                                {
                                    uint16_t max_voltage_raw = ((first_pdo >> 20) & 0x3FF);
                                    uint16_t power_raw = ((first_pdo >> 0) & 0x3FF);
                                    pd_monitor.last_voltage = max_voltage_raw * 50; // 最大电压
                                    pd_monitor.last_current = power_raw * 25; // 功率转换为电流估算
                                    pd_monitor.power_status = STATUS_POWER_TYP;
                                    Serial.printf("[DEBUG] Battery: Vmax=%dmV, Power=%u*250mW\n", 
                                                  pd_monitor.last_voltage, power_raw);
                                }
                                break;
                                
                            case 2: // Variable Supply
                                {
                                    uint16_t max_voltage_raw = ((first_pdo >> 20) & 0x3FF);
                                    uint16_t max_current_raw = ((first_pdo >> 0) & 0x3FF);
                                    pd_monitor.last_voltage = max_voltage_raw * 50; // 最大电压
                                    pd_monitor.last_current = max_current_raw * 10;  // 最大电流
                                    pd_monitor.power_status = STATUS_POWER_TYP;
                                    Serial.printf("[DEBUG] Variable: Vmax=%dmV, Imax=%dmA\n",
                                                  pd_monitor.last_voltage, pd_monitor.last_current);
                                }
                                break;
                                
                            case 3: // Augmented PDO (PPS)
                                {
                                    // 修正：根据USB PD 3.0规范，正确的位域提取
                                    uint16_t voltage_raw = ((first_pdo >> 17) & 0x7FF);  // 11位，位[17:7]
                                    uint16_t current_raw = ((first_pdo >> 7) & 0xFF);    // 8位，位[14:7]
                                    pd_monitor.last_voltage = voltage_raw * 100; // 100mV单位转换为mV
                                    pd_monitor.last_current = current_raw * 50;   // 50mA单位转换为mA
                                    Serial.printf("[DEBUG] 设置为PPS: V=%umV, I=%umA\n", 
                                                  pd_monitor.last_voltage, pd_monitor.last_current);
                                    pd_monitor.power_status = STATUS_POWER_PPS;
                                    Serial.printf("[DEBUG] PPS: power_status设置为%d\n", pd_monitor.power_status);
                                    Serial.printf("[DEBUG] PPS: V=%dmV (%u*100mV), I=%dmA (%u*50mA)\n",
                                                  pd_monitor.last_voltage, voltage_raw, pd_monitor.last_current, current_raw);
                                }
                                break;
                                
                            default:
                                Serial.printf("[DEBUG] Unknown PDO type: %d\n", pdo_type);
                                break;
                        }
                    }
                    
                    // 如果有多个PDO，选择功率最大的作为"默认"电源
                    uint16_t max_power_voltage = 0;
                    uint16_t max_power_current = 0;
                    uint32_t max_power = 0;
                    status_power_t max_power_type = STATUS_POWER_NA;  // 记录最大功率PDO的类型
                    
                    for (uint8_t i = 0; i < num_obj && i < 7; i++) {
                        uint32_t pdo = obj[i];
                        uint8_t type = (pdo >> 30) & 0x03;
                        uint16_t voltage_mv = 0;
                        uint16_t current_ma = 0;
                        uint32_t power_mw = 0;
                        
                        switch (type) {
                            case 0: // Fixed Supply
                                {
                                    uint16_t v_raw = ((pdo >> 10) & 0x3FF);
                                    uint16_t i_raw = ((pdo >> 0) & 0x3FF);
                                    voltage_mv = v_raw * 50;
                                    current_ma = i_raw * 10;
                                    power_mw = voltage_mv * current_ma / 1000;
                                }
                                break;
                            case 2: // Variable Supply
                                {
                                    uint16_t v_raw = ((pdo >> 20) & 0x3FF);
                                    uint16_t i_raw = ((pdo >> 0) & 0x3FF);
                                    voltage_mv = v_raw * 50;
                                    current_ma = i_raw * 10;
                                    power_mw = voltage_mv * current_ma / 1000;
                                }
                                break;
                            case 3: // PPS
                                {
                                    // 修正：根据USB PD 3.0规范，正确的位域提取
                                    uint16_t v_raw = ((pdo >> 17) & 0x7FF);  // 11位，位[17:7]
                                    uint16_t i_raw = ((pdo >> 7) & 0xFF);    // 8位，位[14:7]
                                    voltage_mv = v_raw * 100;
                                    current_ma = i_raw * 50;
                                    power_mw = voltage_mv * current_ma / 1000;
                                }
                                break;
                        }
                        
                        Serial.printf("[DEBUG] PDO[%d]: Type=%d, V=%umV, I=%umA, P=%umW\n",
                                      i, type, voltage_mv, current_ma, power_mw);
                        
                        if (power_mw > max_power) {
                            max_power = power_mw;
                            max_power_voltage = voltage_mv;
                            max_power_current = current_ma;
                            max_power_type = (type == 3) ? STATUS_POWER_PPS : STATUS_POWER_TYP;  // 根据PDO类型设置
                        }
                    }
                    
                    // 更新为最大功率的电源信息，包括类型
                    if (max_power > 0) {
                        Serial.printf("[DEBUG] 更新最大功率PDO: 当前power_status=%d, 新类型=%d\n", 
                                      pd_monitor.power_status, max_power_type);
                        pd_monitor.last_voltage = max_power_voltage;
                        pd_monitor.last_current = max_power_current;
                        pd_monitor.power_status = max_power_type;  // 同时更新电源类型
                        Serial.printf("[DEBUG] Selected max power PDO: V=%umV, I=%umA, P=%umW, Type=%d (power_status=%d)\n",
                                      max_power_voltage, max_power_current, max_power, max_power_type, pd_monitor.power_status);
                    }
                }
                
                // 如果接收到Request消息，记录请求的电源信息
                // 修正：Request在data_msg_list中索引为2，所以类型为0x02
                else if (num_obj > 0 && msg_type == 0x02) {
                    Serial.println("[DEBUG] Request message received!");
                    // Request消息，从设备请求的电源
                    uint32_t request_pdo = obj[0];
                    uint8_t request_type = (request_pdo >> 30) & 0x03;
                    uint16_t voltage = 0;
                    uint16_t current = 0;
                    
                    // 正确解析Request PDO的电源类型和值
                    switch (request_type) {
                        case 0: // Fixed Supply Request
                            voltage = ((request_pdo >> 10) & 0x3FF) * 50; // 50mV单位
                            current = ((request_pdo >> 0) & 0x3FF) * 10;  // 10mA单位
                            // 不更新power_status，保持Source Capabilities的设置
                            break;
                        case 3: // PPS Request
                            voltage = ((request_pdo >> 17) & 0x7FF) * 100; // 100mV单位
                            current = ((request_pdo >> 7) & 0xFF) * 50;    // 50mA单位
                            // 不更新power_status，保持Source Capabilities的设置
                            break;
                    }
                    
                    // 只更新电压电流信息，不更新电源类型
                    pd_monitor.last_voltage = voltage;
                    pd_monitor.last_current = current;
                    Serial.printf("[DEBUG] Request PDO: V=%umV, I=%umA, Type=%d\n", 
                                  voltage, current, request_type);
                }
                
                // 重要：不调用PD_protocol_handle_msg，避免触发协议处理
                // 重要：不调用handle_protocol_event，避免触发PD握手
            }
            
            if (FUSB302_events & FUSB302_EVENT_GOOD_CRC_SENT) {
                // Good CRC发送成功，只统计不响应
                pd_monitor.good_crc_count++;
                
                // 重要：不调用PD_protocol_respond，避免发送响应消息
                // 重要：不调用FUSB302_tx_sop，避免发送任何PD消息
            }
        }
        
        // 更新监听信息
        update_monitor_info();
    }
}

int PD_UFP_c::status_bridge_log_readline(char *buffer, int maxlen)
{
    // 增强的安全检查
    if (!bridge_mode_enabled || !buffer || maxlen <= 0 || maxlen > 1024) {
        return 0;
    }
    
    // 确保pd_monitor结构体已初始化
    if (pd_monitor.last_timestamp == 0 && bridge_mode_enabled) {
        pd_monitor.last_timestamp = clock_ms();
        pd_monitor.packet_count = 0;
        pd_monitor.cc_pin = 0;
        pd_monitor.cc_status = false;
    }
    
    int n = 0;
    char time_str[8];
    
    // 按照status_log_readline的格式生成时间戳
    uint16_t time_ms = (uint16_t)(pd_monitor.last_timestamp % 10000);
    snprintf(time_str, sizeof(time_str), "%04u: ", time_ms);
    
    // 根据日志级别决定输出格式
    if (bridge_log_level == PD_BRIDGE_LOG_LEVEL_BASIC) {
        // 标准模式：只输出电压电流和PDO信息
        float voltage = get_bridge_voltage();
        float current = get_bridge_current();
        uint8_t pdo_count = pd_monitor.src_cap_count;
        uint8_t selected_pos = pd_monitor.selected_position;
        
        if (pd_monitor.cc_status && voltage > 0) {
            n = snprintf(buffer, maxlen, "%s%d.%02dV %d.%02dA pos[%d] PDO[%d]\n",
                        time_str,
                        (int)voltage, (int)((voltage - (int)voltage) * 100 + 0.5f),
                        (int)current, (int)((current - (int)current) * 100 + 0.5f),
                        selected_pos, pdo_count);
        } else {
            n = snprintf(buffer, maxlen, "%sNo PD connection\n", time_str);
        }
    } else {
        // 详细模式：输出所有信息
        String power_mode = get_bridge_power_mode();
        const char* mode_str = power_mode.c_str();
        
        if (pd_monitor.cc_status) {
            // 有连接时的详细输出
            float voltage = get_bridge_voltage();
            float current = get_bridge_current();
            uint32_t power_mw = get_bridge_max_power();
            uint8_t pdo_count = pd_monitor.src_cap_count;
            uint8_t selected_pos = pd_monitor.selected_position;
            uint32_t packet_count = pd_monitor.packet_count;
            uint32_t crc_count = pd_monitor.good_crc_count;
            uint8_t cc_pin = pd_monitor.cc_pin;
            
            // 主要电源信息行
            n = snprintf(buffer, maxlen, "%s%d.%02dV %d.%02dA %s PDO[%d] pos[%d] %uW\n",
                        time_str,
                        (int)voltage, (int)((voltage - (int)voltage) * 100 + 0.5f),
                        (int)current, (int)((current - (int)current) * 100 + 0.5f),
                        mode_str, pdo_count, selected_pos, power_mw / 1000);
            
            // 如果缓冲区还有空间，添加统计信息
            if (n < maxlen - 50) {
                int additional_len = snprintf(buffer + n, maxlen - n, "%s  CC:%d PKT:%u CRC:%u\n",
                                            time_str, cc_pin, packet_count, crc_count);
                n += additional_len;
            }
            
            // 如果缓冲区还有更多空间，添加PDO详细信息
            if (n < maxlen - 80 && pdo_count > 0) {
                // 这里可以添加解析的PDO信息，但由于我们没有存储原始PDO数据，
                // 所以只显示基本信息
                int pdo_len = snprintf(buffer + n, maxlen - n, "%s  Power range: %u-%u mV, %u mA limit\n",
                                     time_str, pd_monitor.last_voltage, pd_monitor.last_voltage, pd_monitor.last_current);
                n += pdo_len;
            }
        } else {
            // 无连接时的输出
            n = snprintf(buffer, maxlen, "%sNo PD device connected\n", time_str);
        }
    }
    
    return n;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// 监听函数实现 - 返回实际数值
///////////////////////////////////////////////////////////////////////////////////////////////////

float PD_UFP_c::get_bridge_voltage(void)
{
    // Bridge模式：优先使用监听数据中的值
    if (bridge_mode_enabled) {
        if (pd_monitor.last_voltage > 0) {
            return pd_monitor.last_voltage / 1000.0f; // 转换为伏特（监听数据已经是mV）
        }
        return 0.0f; // 监听模式下无电压信息时返回0V
    }
    
    // 非Bridge模式：使用原有逻辑
    // 将内部电压值转换为实际电压值（V）
    // 内部电压值以50mV为单位（PPS以20mV为单位）
    if (status_power == STATUS_POWER_PPS) {
        // PPS模式：20mV单位
        return ready_voltage * 0.02f; // 转换为伏特
    } else if (status_power == STATUS_POWER_TYP) {
        // 固定电压模式：50mV单位
        return ready_voltage * 0.05f; // 转换为伏特
    }
    return 0.0f; // 无电源时返回0V
}

float PD_UFP_c::get_bridge_current(void)
{
    // Bridge模式：优先使用监听数据中的值
    if (bridge_mode_enabled) {
        if (pd_monitor.last_current > 0) {
            return pd_monitor.last_current / 1000.0f; // 转换为安培（监听数据已经是mA）
        }
        return 0.0f; // 监听模式下无电流信息时返回0A
    }
    
    // 非Bridge模式：使用原有逻辑
    // 将内部电流值转换为实际电流值（A）
    // 内部电流值以10mA为单位（PPS以50mA为单位）
    if (status_power == STATUS_POWER_PPS) {
        // PPS模式：50mA单位
        return ready_current * 0.05f; // 转换为安培
    } else if (status_power == STATUS_POWER_TYP) {
        // 固定电压模式：10mA单位
        return ready_current * 0.01f; // 转换为安培
    }
    return 0.0f; // 无电源时返回0A
}

String PD_UFP_c::get_bridge_power_mode(void)
{
    // Bridge模式：根据监听状态返回模式字符串
    if (bridge_mode_enabled) {
        switch (pd_monitor.power_status) {
            case STATUS_POWER_TYP:
                return "FIX";  // 固定电压模式
            case STATUS_POWER_PPS:
                return "PPS";  // 可编程电源模式
            case STATUS_POWER_NA:
            default:
                return "MON"; // 监听模式
        }
    }
}

uint32_t PD_UFP_c::get_bridge_packet_count(void)
{
    // 返回PD数据包计数
    return pd_monitor.packet_count;
}

uint8_t PD_UFP_c::get_bridge_src_cap_count(void)
{
    // 返回源能力计数
    return pd_monitor.src_cap_count;
}

uint8_t PD_UFP_c::get_bridge_selected_position(void)
{
    // 返回PD位置
    return pd_monitor.selected_position;
}

uint8_t PD_UFP_c::get_bridge_cc_pin(void)
{
    // 返回CC线状态：0/NULL 1/CC1 2/CC2
    return pd_monitor.cc_pin;
}

uint32_t PD_UFP_c::get_bridge_good_crc_count(void)
{
    // 返回成功CRC计数
    return pd_monitor.good_crc_count;
}

uint32_t PD_UFP_c::get_bridge_reject_count(void)
{
    // 返回拒绝计数
    return pd_monitor.reject_count;
}

bool PD_UFP_c::get_bridge_cc_status(void)
{
    // 返回CC线连接状态
    return pd_monitor.cc_status;
}

void PD_UFP_c::reset_bridge_monitor(void)
{
    // 重置监听数据
    pd_monitor.packet_count = 0;
    pd_monitor.good_crc_count = 0;
    pd_monitor.reject_count = 0;
    pd_monitor.cc_status = false;
    pd_monitor.cc_pin = 0;
    pd_monitor.src_cap_count = 0;
    pd_monitor.selected_position = 0;
    // 保持电压、电流、时间戳不变
}

void PD_UFP_c::set_bridge_log_level(pd_bridge_log_level_t level)
{
    bridge_log_level = level;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// 监听模式下的电源信息获取函数实现
///////////////////////////////////////////////////////////////////////////////////////////////////

String PD_UFP_c::get_bridge_power_info_string(void)
{
    if (!bridge_mode_enabled) {
        return "Bridge模式未启用";
    }
    
    if (!pd_monitor.cc_status) {
        return "未检测到PD连接";
    }
    
    if (pd_monitor.src_cap_count == 0) {
        return "连接中，等待PD信息...";
    }
    
    String info = "PD电源信息:\n";
    info += "  电压: " + String(pd_monitor.last_voltage / 1000.0f, 2) + "V\n";
    info += "  电流: " + String(pd_monitor.last_current / 1000.0f, 2) + "A\n";
    info += "  功率: " + String((pd_monitor.last_voltage * pd_monitor.last_current) / 1000000.0f, 2) + "W\n";
    info += "  模式: " + get_bridge_power_mode() + "\n";
    info += "  PDO数量: " + String(pd_monitor.src_cap_count) + "\n";
    info += "  包计数: " + String(pd_monitor.packet_count) + "\n";
    
    return info;
}

uint32_t PD_UFP_c::get_bridge_max_power(void)
{
    if (!bridge_mode_enabled || !pd_monitor.cc_status) {
        return 0;
    }
    
    return (pd_monitor.last_voltage * pd_monitor.last_current) / 1000; // 转换为mW
}

uint16_t PD_UFP_c::get_bridge_voltage_range_min(void)
{
    if (!bridge_mode_enabled || !pd_monitor.cc_status) {
        return 0;
    }
    
    // 这里可以扩展为解析多个PDO获取电压范围
    // 目前返回当前电压值
    return pd_monitor.last_voltage;
}

uint16_t PD_UFP_c::get_bridge_voltage_range_max(void)
{
    if (!bridge_mode_enabled || !pd_monitor.cc_status) {
        return 0;
    }
    
    // 这里可以扩展为解析多个PDO获取电压范围
    // 目前返回当前电压值
    return pd_monitor.last_voltage;
}

uint16_t PD_UFP_c::get_bridge_current_limit(void)
{
    if (!bridge_mode_enabled || !pd_monitor.cc_status) {
        return 0;
    }
    
    return pd_monitor.last_current;
}

bool PD_UFP_c::is_bridge_pps_capable(void)
{
    if (!bridge_mode_enabled || !pd_monitor.cc_status || pd_monitor.src_cap_count == 0) {
        return false;
    }
    
    return (pd_monitor.power_status == STATUS_POWER_PPS);
}


